package com.example.yjccccc.myrobot;

/**
 * Created by compsci on 10/10/15.
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

// *** has to use  MyCanvas(Context c, AttributeSet attrs)
// dashed line not working

public class MyCanvas extends View {

    Path cv_path;
    Paint cv_paint;
    Paint cv_paint_segment;
    Boolean cv_flag = true;
    MainActivity a = new MainActivity();
    int speed = a.getSpeed;


    public MyCanvas(Context c, AttributeSet attrs) {

        super(c, attrs);
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // TODO Auto-generated method stub
        super.onDraw(canvas);

        cv_path = new Path();
        cv_paint = new Paint();
        cv_paint_segment = new Paint();
        cv_paint.setColor(Color.RED);
        cv_paint.setAlpha(255);
        cv_paint_segment.setColor(Color.parseColor("#008000"));
        //cv_paint.setStyle(Paint.Style.STROKE);
        cv_paint.setStrokeWidth((float) 5.0);
        cv_paint_segment.setStrokeWidth((float) 10.0);
        cv_paint.setPathEffect(new DashPathEffect(new float[]{4, 2, 4, 2}, 0));
        cv_paint.setPathEffect(new DashPathEffect(new float[]{10, 10}, 5));


        //canvas.drawCircle(120, 120, 120, cv_paint_segment);
        //canvas.drawLine(120, 120, (int) (120 + 120 * Math.cos(speed)), (int) (120 - 120 * Math.sin(speed)), cv_paint);




    }

    public void cp_toggleFlag() {
        cv_flag = !cv_flag;
        invalidate();
    }

}

