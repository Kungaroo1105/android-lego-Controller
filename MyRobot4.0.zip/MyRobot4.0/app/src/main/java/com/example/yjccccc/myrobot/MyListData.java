package com.example.yjccccc.myrobot;

/**
 * Created by YJccccc on 15-10-2.
 */
public class MyListData {

    private String mv_symbol;


    public MyListData(){
    }

    public MyListData(String symbol){
        this.mv_symbol = symbol;

    }

    public String getSymbol(){
        return this.mv_symbol;
    }



}
