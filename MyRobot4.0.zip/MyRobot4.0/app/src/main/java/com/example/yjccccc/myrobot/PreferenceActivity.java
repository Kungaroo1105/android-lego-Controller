package com.example.yjccccc.myrobot;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by YJccccc on 15/11/26.
 */
//pop-up window
public class PreferenceActivity extends AppCompatActivity implements View.OnClickListener {

    //Button Button_Pre1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference);

        //Button_Pre1 = (Button) findViewById(R.id.tv1_preference);
//        Button_Pre1.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        //this.finish();
    }
}
