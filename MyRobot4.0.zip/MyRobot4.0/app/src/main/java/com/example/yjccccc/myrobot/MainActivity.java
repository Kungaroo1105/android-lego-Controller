package com.example.yjccccc.myrobot;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SensorEventListener {
    private SensorManager sm;

    final String CC_ROBOTNAME = "NXT05";//match the robot model
    //TextView cv_label;
    TextView tbconnect;
    TextView cv_label;
    TextView sub_speed;
    boolean cv_moveFlag = false;
    boolean intentflag=false;
    boolean sensorflag= false;
    boolean infoflag = false;
    boolean gravityflag =false;
    int robotStatus=0;
    int speed0=50;
    int speed1=50;
    int getSpeed=0;
    MainActivity cv_this = this;
    MyCanvas cv_myCanvas;
    ImageButton btnIntent;
    ImageButton btnSensor;
    MyTimerTask myTimerTask;
    Timer timer;
    int cv_batterypower;
    boolean moving;

    boolean isConnected;

    TextView trybattery;

    // BT Variables
    private BluetoothAdapter btInterface;
    private Set<BluetoothDevice> pairedDevices;
    private BluetoothSocket socket;
    private BluetoothDevice bd;

    private BroadcastReceiver btMonitor = null;
    private InputStream is = null;
    private OutputStream os = null;

    Timer mBatteryTimer;
    int mBatteryLevel;



    Button button1;
    Button button2;
    Button btncontroller2;
    ImageButton Button_Pre;
    ImageButton btnInfo;
    ImageView bt;
    ProgressBar pbbattery;
    float ax;
    float ay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        button1 = (Button) findViewById(R.id.tv1_connect);
        button2 = (Button) findViewById(R.id.tv2_disconnect);
        Button_Pre = (ImageButton) findViewById(R.id.tv1_preference);
        bt = (ImageView)findViewById(R.id.iv1_bluetooth);
        pbbattery = (ProgressBar)findViewById(R.id.pb1_battery);
        pbbattery.setVisibility(View.VISIBLE);

        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        Button_Pre.setOnClickListener(this);
        button1.setEnabled(true);
        button2.setEnabled(false);
        btncontroller2 = (Button)findViewById(R.id.btncontroller2);
        btncontroller2.setOnClickListener(this);
        Button_Pre.setEnabled(true);

        isConnected = false;
        moving = false;

        trybattery = (TextView)findViewById(R.id.tv1_battery);

        tbconnect = (TextView)findViewById(R.id.tv1_btstatu);

        setupBTMonitor();
        btnIntent = (ImageButton) findViewById(R.id.btnIntent);
        btnIntent.setOnClickListener(this);
        btnIntent.setEnabled(false);
        btnSensor = (ImageButton) findViewById(R.id.btnSensor);
        btnSensor.setOnClickListener(this);
        btnSensor.setEnabled(false);
        btnInfo = (ImageButton) findViewById(R.id.btnInfo);
        btnInfo.setOnClickListener(this);
        btnInfo.setEnabled(true);
        btnIsEnable();

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        //sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onDestroy() {
        sm.unregisterListener(this);
        super.onDestroy();
    }

    public void onSensorChanged(SensorEvent event) {
        if (Sensor.TYPE_ACCELEROMETER != event.sensor.getType()) {
            return;
        }

        float[] values = event.values;
        ax = values[0];
        ay = values[1];


        if (isConnected && moving) {
            //System.out.println((int) ax + "and" + (int) ay);
            boolean turn = false;

            if((ax > 3 || ax < -3) && (ay >= 3 || ay <=8.5)){
                if (ax > 3)
                {
                    cfp_moveMotor(0, 50, 0x20);
                    cfp_moveMotor(1, -50, 0x20);
                }
                else if (ax < -3){
                    cfp_moveMotor(0, -50, 0x20);
                    cfp_moveMotor(1, 50, 0x20);
                }
                else
                {
                    cfp_moveMotor(0, 0, 0x00);
                    cfp_moveMotor(1, 0, 0x00);
                }
            }
            else
            {
                if ( ay < 3 ) {
                    cfp_moveMotor(0, 50, 0x20);
                    cfp_moveMotor(1, 50, 0x20);
                }
                else if ( ay > 8.5){
                    cfp_moveMotor(0, -50, 0x20);
                    cfp_moveMotor(1, -50, 0x20);
                }
                else
                {
                    cfp_moveMotor(0, 0, 0x00);
                    cfp_moveMotor(1, 0, 0x00);
                }
            }


            System.out.println(ax +"and" + ay);
        }

        //System.out.println(ax +"and" + ay);

//        if (ax>9 && ax<11 && ay>-1 && ay<1){System.out.println("前进");}
//
//        if (ax>6 && ax<9 && ay>-10 && ay<-1){System.out.println("左转");}
//        if (ax>3 && ax<6 && ay>-10 && ay<-1){System.out.println("超级左转");}
//        if (ax>0 && ax<3 && ay>-10 && ay<-1){System.out.println("无敌大左转");}
//
//        if (ax>6 && ax<9 && ay>0 && ay<10){System.out.println("右转");}
//        if (ax>3 && ax<6 && ay>0 && ay<10){System.out.println("超级右转");}
//        if (ax>0 && ax<3 && ay>0 && ay<10){System.out.println("无敌大右转");}
    }

    public void onAccuracyChanged(Sensor arg0, int arg1) {

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        registerReceiver(btMonitor, new IntentFilter("android.bluetooth.device.action.ACL_CONNECTED"));
        registerReceiver(btMonitor, new IntentFilter("android.bluetooth.device.action.ACL_DISCONNECTED"));
        if (isConnected) {
            cfp_connectNXT();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        //unregisterReceiver(btMonitor);
    }

    private void cfp_connectNXT() {
        try	{
            btInterface = BluetoothAdapter.getDefaultAdapter();
            pairedDevices = btInterface.getBondedDevices();
            Iterator<BluetoothDevice> it = pairedDevices.iterator();
            while (it.hasNext()) {
                bd = it.next();
                if (bd.getName().equalsIgnoreCase(CC_ROBOTNAME)) {
                    try {
                        socket = bd.createRfcommSocketToServiceRecord(
                                java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                        socket.connect();
                        bt.setImageResource(R.drawable.btlogo);//light the blue tooth logo
                        tbconnect.setText("Connected");//note message
                        batteryLevel();
                        btnIntent.setEnabled(true);
                        btnSensor.setEnabled(true);
                        btnIsEnable();
                        isConnected = true;


                        timer = new Timer();
                        myTimerTask = new MyTimerTask();
                        timer.schedule(myTimerTask, 0, 120000);

                    }
                    catch (Exception e) {
//                        tbconnect.setText("Error interacting with remote device [" +
//                                e.getMessage() + "]");
                        tbconnect.setText("Error interacting with remote device");
                    }
                }
            }
        }
        catch (Exception e) {
            tbconnect.setText("Failed in findRobot() " + e.getMessage());
        }


//        try {
//            System.out.println(1);
//            byte[] buffer = new byte[15];
//
//            buffer[0] = 15 - 1;            //length lsb
//            buffer[1] = 0;                        // length msb
//            buffer[2] = (byte) 0x80;                    // direct command (with response)
//            buffer[3] = (byte) 0x02;                    // set output state
//            buffer[4] = 0x00;                    // output 1 (motor B)
//            buffer[5] = (byte) 's'; // filename starting here
//            buffer[6] = (byte) 'h';
//            buffer[7] = (byte) 'o';
//            buffer[8] = (byte) 'u';//start of .rso
//            buffer[9] = (byte) 't';
//            buffer[10] = (byte) '.';
//            buffer[11] = (byte) 'r';
//            buffer[12] = (byte) 's';
//            buffer[13] = (byte) 'o';;
//            buffer[14] = 0;
//            if (os == null) {
//                //os = MainActivity.socket.getOutputStream();
//                os = socket.getOutputStream();
//            }
//            if (is == null) {
//                //is = MainActivity.socket.getInputStream();
//                is = socket.getInputStream();
//            }
//            os.write(buffer);
//            os.flush();
//
//        } catch (Exception e) {
//            int cv_batterypower = -1;
//        }



    }

    private void cfp_disconnectNXT() {
        try {
            socket.close();
            is.close();
            os.close();
            tbconnect.setText(bd.getName() + " is disconnect ");
            bt.setImageResource(R.drawable.btlogo1);//cancel the blue tooth logo
            //tbconnect.setText("Disconnected");//note message
            isConnected = false;
            btnIntent.setEnabled(false);
            btnSensor.setEnabled(false);
            btnIsEnable();
        } catch (Exception e) {
            tbconnect.setText("Error in disconnect -> " + e.getMessage());
        }

    }

    private void setupBTMonitor() {
        btMonitor = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(
                        "android.bluetooth.device.action.ACL_CONNECTED")) {
                    try {
                        is = socket.getInputStream();
                        os = socket.getOutputStream();
                        //tbconnect.setText("Connect to " + bd.getName() + " at " + bd.getAddress());

                    } catch (Exception e) {
                        cfp_disconnectNXT();
                        is = null;
                        os = null;
                    }
                    ////cv_label.setText("Connection is good");
                }
                if (intent.getAction().equals(
                        "android.bluetooth.device.action.ACL_DISCONNECTED")) {
                    tbconnect.setText("Connection is broken");
                    button1.setEnabled(true);
                }
            }
        };
    }

    private void batteryLevel() {
        BroadcastReceiver batteryLevelReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                context.unregisterReceiver(this);
                int rawlevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int level = -1;
                if (rawlevel >= 0 && scale > 0) {
                    level = (rawlevel * 100) / scale;
                }
                trybattery.setText("Battery Level Remaining: " + level + "%");
                pbbattery.setProgress(level);
            }
        };
        IntentFilter batteryLevelFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryLevelReceiver, batteryLevelFilter);
    }

    private void cfp_moveMotor(int motor,int speed, int state) {
        try {
            byte[] buffer = new byte[15];

            buffer[0] = (byte) (15-2);			//length lsb
            buffer[1] = 0;						// length msb
            buffer[2] =  0;						// direct command (with response)
            buffer[3] = 0x04;					// set output state
            buffer[4] = (byte) motor;			// output 1 (motor B)
            buffer[5] = (byte) speed;			// power
            buffer[6] = 1 + 2;					// motor on + brake between PWM
            buffer[7] = 0;						// regulation
            buffer[8] = 0;						// turn ration??
            buffer[9] = (byte) state; //0x20;					// run state
            buffer[10] = 0;
            buffer[11] = 0;
            buffer[12] = 0;
            buffer[13] = 0;
            buffer[14] = 0;

            os.write(buffer);
            os.flush();
        }
        catch (Exception e) {
            tbconnect.setText("Error in MoveForward(" + e.getMessage() + ")");
        }



    }

//    private void cfp_pollBattery(int interval) {
//        mBatteryTimer = new Timer();
//        mBatteryTimer.scheduleAtFixedRate(new TimerTask() {
//            public void run() {
//                if (misNXT_connected) {
//                    mBatteryLevel = cfp_getBatteryLevel();
//                    // normalize battery level (0-100)
//                    msetHandlerState(NXTControlActivity.
//                            MESSAGE_BATTERY_READY, NXT_STATE_CONNECTED);
//                }
//            }
//        }, 0, interval);
//    }
//
//    private int cfp_getBatteryLevel() {
//        int volt = 100;
//        try {
//            // Command: {0x00, 0x0B}, 0x00 -> response required
//            byte[] btMsg = {0x02, 0x00, 0x00, 0x0b};
//            btMsg[3] = NXT_COMMAND_GET_BATTERY_LEVEL; //0x0b
//            mthreadWrite(btMsg, 1000);
//
//            byte response [] = mthreadRead(NXT_COMMAND_GET_BATTERY_LEVEL, 50);
//            if (response == null) {
//                Log.e(tag, "No battery level response??");
//            }
//            else {
//                //for (int i=0;i< response.length;i++)
//                //Log.i(tag,"\tByte " + i + " == " + response[i]);
//                volt = ...
//                //Log.i(tag,"Battery = " + volt);
//            }
//        }
//        catch (Exception e) {
//            Log.e(tag,"Error in reading battery level -> "+ e.getMessage());
//        }
//        return volt;
//    }

    @Override
    public void onClick(View v) { // Parameter v stands for the view that was clicked.

        v.setEnabled(false);
        // getId() returns this view's identifier.
        if(v.getId() == R.id.tv1_connect) {
            button2.setEnabled(true);
            //cfp_connectNXT();
            isConnected = true;
            Intent lv_it = new Intent (this, SubActivity.class);
            startActivity(lv_it);

        }
        else if(v.getId() == R.id.tv2_disconnect){
//            button1.setEnabled(true);
            cfp_disconnectNXT();
        }
        if(v.getId() == R.id.tv1_preference) {
            Button_Pre.setEnabled(true);
            Intent lv_it = new Intent (this, PreferenceActivity.class);
            startActivity(lv_it);
        }
        if(v.getId() == R.id.btnIntent) {
            //System.out.println("===========================f");
            setContentView(R.layout.activity_sub);
            ImageButton btnStop = (ImageButton) findViewById(R.id.btnStop);
            btnStop.setEnabled(false);
            intentflag=true;
            btnIntent.setEnabled(true);
        }
        if (intentflag==true) {
            move(v);
        }
        if(v.getId() == R.id.btnSensor) {
            //System.out.println("===========================f");
            setContentView(R.layout.activity_sensor);
            sensorflag=true;
            btnSensor.setEnabled(true);
            String[] symbleArray = {"distance", "light", "servo", "sound", "touch"};
            final ArrayList<MyListData> lv_listItems = new ArrayList<MyListData>();
            for (int i = 0; i < symbleArray.length; i++) {
                lv_listItems.add(new MyListData(symbleArray[i]));
            }
            MyListAdapter lv_adapter = new MyListAdapter(this, lv_listItems);

            ListView listView = (ListView) findViewById(R.id.xv_tabletList);
            listView.setAdapter(lv_adapter);

        }

        if (v.getId()==R.id.btncontroller2){

            if (moving== false){
                moving=true;
                btncontroller2.setEnabled(true);
                //sm.unregisterListener(this);
            }
            else if (moving== true) {
                moving = false;
                btncontroller2.setEnabled(true);
                //sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
            }

//            setContentView(R.layout.activity_gravity);
//
//            Button btnStartStop= (Button)findViewById(R.id.btnStartStop);
//            btnStartStop.setOnClickListener(this);
//            if (v.getId()==R.id.btnStartStop);
//            {
//                if (moving== false){
//                    moving=true;
//                    //sm.unregisterListener(this);
//                }
//                else if (moving== true) {
//                    moving = false;
//                    //sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
//                }
//                System.out.print(moving);
//            }
//            btnStartStop.setEnabled(true);
//            System.out.print(moving);
//            gravityflag=true;
        }

        //if (gravityflag==true){
            //gravCtr(v);
        //}


        if (sensorflag==true){
            activesensor(v);
        }
        if(v.getId() == R.id.btnInfo) {
            setContentView(R.layout.activity_info);
//            ImageButton btnInfotoMain = (ImageButton) findViewById(R.id.btnInfotoMain);
//            btnInfotoMain.setOnClickListener(this);
//            btnInfotoMain.setEnabled(true);
            ImageView mImageView;
            mImageView = (ImageView)findViewById(R.id.imageView2);
            mImageView.setImageResource(R.drawable.group5_pic);
            Log.d("////////////", "////////////////");
            infoflag=true;
        }
        if (infoflag==true){
            gohome(v);
        }


    }

    public void gravCtr(View v){


//        Button btnStartStop= (Button)findViewById(R.id.btnStartStop);
//        btnStartStop.setOnClickListener(this);
//        if (v.getId()==R.id.btnStartStop);
//        {
//            if (moving== false){
//                moving=true;
//                //sm.unregisterListener(this);
//            }
//            else if (moving== true) {
//                moving = false;
//                //sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
//            }
//            System.out.print(moving);
//        }
//        btnStartStop.setEnabled(true);

        if (moving==true){
            System.out.println((int)ax +"and" +(int)ay);
            if ((int)ax>9 && (int)ax<11 && (int)ay>-1 && (int)ay<1){
                cfp_moveMotor(0, 0, 0x00);
                cfp_moveMotor(1, 50, 0x00);
            System.out.println("////////////");}

//            if (ax>6 && ax<9 && ay>-10 && ay<-1){
//                cfp_moveMotor(0, 0, 0x00);
//                cfp_moveMotor(1, 50, 0x00);
//            }
//            if (ax>3 && ax<6 && ay>-10 && ay<-1){
//                cfp_moveMotor(0, 0, 0x00);
//                cfp_moveMotor(1, 50, 0x00);
//            }
//            if (ax>0 && ax<3 && ay>-10 && ay<-1){
//                cfp_moveMotor(0, 0, 0x00);
//                cfp_moveMotor(1, 50, 0x00);
//            }
            else {cfp_moveMotor(0, 50, 0x00);
                cfp_moveMotor(1, 0, 0x00);}
        }
        else {
            cfp_moveMotor(0, speed0, 0x20);
            cfp_moveMotor(1, speed1, 0x20);
        }


//        if (ax>6 && ax<9 && ay>0 && ay<10){System.out.println("右转");}
//        if (ax>3 && ax<6 && ay>0 && ay<10){System.out.println("超级右转");}
//        if (ax>0 && ax<3 && ay>0 && ay<10){System.out.println("无敌大右转");}



    }



    public void gohome(View v){
        ImageButton btnInfotoMain = (ImageButton) findViewById(R.id.btnInfotoMain);
        btnInfotoMain.setOnClickListener(this);
        if(v.getId() == R.id.btnInfotoMain){
            setContentView(R.layout.activity_main);
            btnInfotoMain.setEnabled(true);
            Log.d("////////////", "////////////////");
            infoflag=false;
            initView();


        }
    }
    public void showSpeed(){
        sub_speed.setTextColor(Color.WHITE);
        sub_speed.setRotation(90);
        sub_speed.setText("Speed:   Left:" + speed0 + ", Right:" + speed1 + '\n' + "Total speed: " + getSpeed);
    }

// function move is called when shifting to control view
public void activesensor(View v){
    ImageButton btnSensortoMain = (ImageButton) findViewById(R.id.btnSensortoMain);
    btnSensortoMain.setOnClickListener(this);
    ImageButton btnSensortoController = (ImageButton) findViewById(R.id.btnSensortoController);
    btnSensortoController.setOnClickListener(this);
    if(v.getId() == R.id.btnSensortoMain) {
        setContentView(R.layout.activity_main);
        sensorflag=false;
        btnSensortoMain.setEnabled(true);
        initView();
    }

    if(v.getId() == R.id.btnSensortoController) {
            btnSensortoController.setEnabled(true);
            setContentView(R.layout.activity_sub);
            sensorflag=false;
            intentflag=true;
            move(v);
            btnIsEnable();
        }
        //btnIntent.setEnabled(true);

    }


    public void move(View v){
        ImageButton btnForward = (ImageButton) findViewById(R.id.btnForward);
        ImageButton btnBack = (ImageButton) findViewById(R.id.btnBack);
        //btnBack.setOnClickListener(this);
        btnForward.getBackground().setAlpha(0);
        btnBack.getBackground().setAlpha(0);
        ImageButton btnLeft = (ImageButton) findViewById(R.id.btnLeft);
        //btnLeft.setOnClickListener(this);
        ImageButton btnRight = (ImageButton) findViewById(R.id.btnRight);
        //btnRight.setOnClickListener(this);
        ImageButton btnAcc = (ImageButton) findViewById(R.id.btnAcc);
        btnAcc.setOnClickListener(this);
        ImageButton btnDec = (ImageButton) findViewById(R.id.btnDec);
        btnDec.setOnClickListener(this);
        ImageButton btnGoback = (ImageButton) findViewById(R.id.btnGoback);
        btnGoback.setOnClickListener(this);
        ImageButton btnLeftForward = (ImageButton) findViewById(R.id.btnLeftForward);
        btnLeftForward.setOnClickListener(this);
        ImageButton btnRightForward = (ImageButton) findViewById(R.id.btnRightForward);
        btnRightForward.setOnClickListener(this);
        btnLeft.getBackground().setAlpha(0);
        btnRight.getBackground().setAlpha(0);
        btnAcc.getBackground().setAlpha(0);
        btnDec.getBackground().setAlpha(0);
        btnGoback.getBackground().setAlpha(0);
        btnLeftForward.getBackground().setAlpha(0);
        btnRightForward.getBackground().setAlpha(0);
        btnGoback.getBackground().setAlpha(0);
        sub_speed= (TextView)findViewById(R.id.speedText);
        cv_myCanvas = (MyCanvas) findViewById(R.id.xv_canvas);


        if (v.getId() == R.id.btnAcc) {
            if(speed0<90 && speed0>-1 && speed1<90 && speed1>-1) {
                speed0+=10;
                speed1+=10;
            }
            else if(speed0>-90 && speed0<-1 && speed1>-90 && speed1<-1) {
                speed0-=10;
                speed1-=10;
            }
            showSpeed();
            btnAcc.setEnabled(true);
        }
        if (v.getId() == R.id.btnDec) {
            if(speed0>0 && speed1>0){
                speed0-=10;
                speed1-=10;}
            else if(speed0<0 && speed1<0){
                speed0+=10;
                speed1+=10;}
            btnDec.setEnabled(true);
            showSpeed();


        }


//        if (v.getId() == R.id.btnForward) {
//            btnForward.setEnabled(false);
//            cfp_moveMotor(0, 50, 0x20);
//            cfp_moveMotor(1, 50, 0x20);
//            btnStop.setEnabled(true);
//            robotStatus=1;
//        }
//        if (v.getId() == R.id.btnBack) {
//            btnBack.setEnabled(false);
//            cfp_moveMotor(0, -50, 0x20);
//            cfp_moveMotor(1, -50, 0x20);
//            btnStop.setEnabled(true);
//            robotStatus=-1;
//        }
        btnForward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, speed0, 0x00);
                    cfp_moveMotor(1, speed1, 0x00);
                    getSpeed=0;
                    // Do what you want
                    showSpeed();
                    cv_myCanvas = (MyCanvas) findViewById(R.id.xv_canvas);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, speed0, 0x20);
                    cfp_moveMotor(1, speed1, 0x20);
                    getSpeed=(speed0+speed1)/2;
                    // Do what you want
                    showSpeed();
                    cv_myCanvas = (MyCanvas) findViewById(R.id.xv_canvas);
                    return true;
                }
                return false;

            }
        });

        btnBack.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, speed0, 0x00);
                    cfp_moveMotor(1, speed1, 0x00);
                    // Do what you want
                    getSpeed=0;
                    Log.d("//////////",getSpeed+"");
                    showSpeed();
                    cv_myCanvas = (MyCanvas) findViewById(R.id.xv_canvas);
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, -speed0, 0x20);
                    cfp_moveMotor(1, -speed1, 0x20);
                    // Do what you want
                    getSpeed=-(speed0+speed1)/2;
                    showSpeed();
                    cv_myCanvas = (MyCanvas) findViewById(R.id.xv_canvas);
                    return true;
                }
                return false;
            }
        });

        btnLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, 50, 0x00);
                    cfp_moveMotor(1, 50, 0x00);
                    // Do what you want
                    getSpeed=0;
                    showSpeed();
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, 50, 0x20);
                    cfp_moveMotor(1, -50, 0x20);
                    // Do what you want
                    getSpeed=0/2;
                    sub_speed.setTextColor(Color.WHITE);
                    sub_speed.setRotation(90);
                    sub_speed.setText("Speed:   Left: -50, Right: 50 "+ '\n' + "Total speed: " + getSpeed);
                    return true;
                }
                return false;
            }
        });
        btnRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, 50, 0x00);
                    cfp_moveMotor(1, 50, 0x00);
                    // Do what you want
                    getSpeed=0;
                    showSpeed();
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, -50, 0x20);
                    cfp_moveMotor(1, 50, 0x20);
                    // Do what you want
                    getSpeed=0/2;
                    sub_speed.setTextColor(Color.WHITE);
                    sub_speed.setRotation(90);
                    sub_speed.setText("Speed:   Left: 50, Right: -50 " + '\n' + "Total speed: " + getSpeed);
                    return true;
                }
                return false;
            }
        });
        btnRightForward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, 50, 0x00);
                    cfp_moveMotor(1, 50, 0x00);
                    // Do what you want
                    getSpeed=0;
                    showSpeed();
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, 40, 0x20);
                    cfp_moveMotor(1, 80, 0x20);
                    // Do what you want
                    getSpeed=70;
                    sub_speed.setTextColor(Color.WHITE);
                    sub_speed.setRotation(90);
                    sub_speed.setText("Speed:   Left: 80, Right: 60 " + '\n' + "Total speed: " + getSpeed);
                    return true;
                }
                return false;
            }
        });
        btnLeftForward.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    cfp_moveMotor(0, 50, 0x00);
                    cfp_moveMotor(1, 50, 0x00);
                    // Do what you want
                    getSpeed=0;
                    showSpeed();
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    cfp_moveMotor(0, 80, 0x20);
                    cfp_moveMotor(1, 40, 0x20);
                    // Do what you want
                    getSpeed=70;
                    sub_speed.setTextColor(Color.WHITE);
                    sub_speed.setRotation(90);
                    sub_speed.setText("Speed:   Left: 60, Right: 80 " + '\n' + "Total speed: " + getSpeed);
                    return true;
                }
                return false;
            }
        });


        if(v.getId() == R.id.btnGoback) {
            setContentView(R.layout.activity_main);
            intentflag=false;
            btnGoback.setEnabled(true);
            initView();
        }

    }

    //function move end


    public void initView(){
        btnIntent = (ImageButton) findViewById(R.id.btnIntent);
        btnIntent.setOnClickListener(this);
        btnSensor= (ImageButton) findViewById(R.id.btnSensor);
        btnSensor.setOnClickListener(this);
        Button_Pre = (ImageButton) findViewById(R.id.tv1_preference);
        Button_Pre.setEnabled(true);
        Button_Pre.setOnClickListener(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tbconnect = (TextView)findViewById(R.id.tv1_btstatu);
        button1 = (Button) findViewById(R.id.tv1_connect);
        button2 = (Button) findViewById(R.id.tv2_disconnect);
        trybattery = (TextView)findViewById(R.id.tv1_battery);
        pbbattery = (ProgressBar)findViewById(R.id.pb1_battery);
        bt = (ImageView) findViewById(R.id.iv1_bluetooth);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        btnInfo = (ImageButton) findViewById(R.id.btnInfo);
        btnInfo.setOnClickListener(this);
        btnInfo.setEnabled(true);
        btncontroller2 = (Button)findViewById(R.id.btncontroller2);
        btncontroller2.setOnClickListener(this);



        if (isConnected) {
            bt.setImageResource(R.drawable.btlogo);
            button1.setEnabled(false);
            button2.setEnabled(true);
            tbconnect.setText("Connected");
            btnIntent.setEnabled(true);
            btnSensor.setEnabled(true);
            btnIsEnable();
        }
        else{
            bt.setImageResource(R.drawable.btlogo1);
            button1.setEnabled(true);
            button2.setEnabled(false);
            tbconnect.setText("Disconnected");
            btnIntent.setEnabled(false);
            btnSensor.setEnabled(false);
            btnIsEnable();
        }
        //cfp_connectNXT();
        setupBTMonitor();
        batteryLevel();
    }

    public void btnIsEnable(){
        if (btnIntent.isEnabled()){
            btnIntent.setAlpha((float)1.0);
        }
        else btnIntent.setAlpha((float)0.5);

        if (btnSensor.isEnabled()){
            btnSensor.setAlpha((float)1.0);
        }
        else btnSensor.setAlpha((float)0.5);


    }


    public void updateBattery() {

        try {
            System.out.println(1);
            byte[] buffer = new byte[15];

            buffer[0] = (byte) (15 - 2);            //length lsb
            buffer[1] = 0;                        // length msb
            buffer[2] = 0x00;                    // direct command (with response)
            buffer[3] = 0x0B;                    // set output state
            buffer[4] = 0;                    // output 1 (motor B)
            buffer[5] = 0;                        // power
            buffer[6] = 0;                        // motor on + brake between PWM
            buffer[7] = 0;                        // regulation
            buffer[8] = 0;                        // turn ration??
            buffer[9] = 0;                    // run state
            buffer[10] = 0;
            buffer[11] = 0;
            buffer[12] = 0;
            buffer[13] = 0;
            buffer[14] = 0;

            if (os == null) {
                os = socket.getOutputStream();
            }
            if (is == null) {
                is = socket.getInputStream();
            }
            os.write(buffer);
            os.flush();
            byte[] mv_batteryresponse = new byte[7];
            int batteryResponse = is.read(mv_batteryresponse);
            for (int i = 0; i < 7; i++){
                System.out.printf("0x%02X \n", mv_batteryresponse[i]);
            }
//
            int batteryPower = ((mv_batteryresponse[6] << 8) & 0x0000ff00) | (mv_batteryresponse[5] & 0x000000ff);
            double m_double = (double) batteryPower;
            cv_batterypower = ((int) ((m_double / 9000) * 100));
            System.out.println("powerrrrr======" + cv_batterypower);
            pbbattery.setProgress(cv_batterypower);
            trybattery.setText("Battery Level Remaining: " + cv_batterypower + "%");
            is.reset();
            //m_battery.setText("Battery Power  " + cv_batterypower + "%");
        } catch (Exception e) {
            cv_batterypower = -1;
        }

//=====ssss woops.rso\0\0\0\0\0\0\0\0\0\0\0
        //String s = "woops.rso";
        //s.getBytes(StandardCharsets.US_ASCII);


    }


    class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    updateBattery();
                    //updateUI(getInfo(lv_url));
                    //lv_current_time.setText(getTime());
                }
            });
        }
    }

}


