package com.example.yjccccc.myrobot;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Iterator;
import java.util.Set;

/**
 * Created by YJccccc on 15/11/12.
 */
public class SubActivity extends AppCompatActivity implements View.OnClickListener {
    final String CC_ROBOTNAME = "NXT05";
    TextView cv_label;

    // BT Variables
    private BluetoothAdapter btInterface;
    private Set<BluetoothDevice> pairedDevices;
    private BluetoothSocket socket;
    private BluetoothDevice bd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop);
        cv_label = (TextView)findViewById(R.id.cv_label);
        cfp_findBTList();
    }

    @Override
    public void onClick(View view) {
        this.finish();

    }


    private void cfp_findBTList() {
        try {
            btInterface = BluetoothAdapter.getDefaultAdapter();
            pairedDevices = btInterface.getBondedDevices();
            Iterator<BluetoothDevice> it = pairedDevices.iterator();
            while (it.hasNext())  {
                BluetoothDevice bd = it.next();
                //if (bd.getName().equalsIgnoreCase(CC_ROBOTNAME)) {
                    cv_label.setText(bd.getName() + " \n "+ bd.getAddress());
                    return;
                //}
            }
            cv_label.setText(CC_ROBOTNAME + " is NOT in paired list");
        }
        catch (Exception e) {
            cv_label.setText("Failed in findRobot() " + e.getMessage());
        }
    }


}
